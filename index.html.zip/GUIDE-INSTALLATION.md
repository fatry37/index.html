# 🚀 Guide d'installation Vide-Frigo V3
## Gemini AI · Firebase · Confettis · Gamification · Pub

---

## CE QU'IL FAUT CONFIGURER (2 services, ~20 min)

| Service | Rôle | Gratuit jusqu'à |
|---|---|---|
| Firebase | Comptes + base de données | 50k utilisateurs/mois |
| Gemini API | Générer les recettes | 1 500 requêtes/jour |
| Google AdSense | Bandeau pub (revenus) | N/A — tu gagnes de l'argent |
| Netlify | Hébergement web | Illimité |

---

## ÉTAPE 1 — Clé API Gemini

1. Va sur **https://aistudio.google.com/apikey**
2. Connecte-toi avec un compte Google
3. Clique **"Create API key"** → **"Create API key in new project"**
4. Copie la clé — commence par `AIzaSy...`
5. Garde-la de côté

---

## ÉTAPE 2 — Créer le projet Firebase

### 2.1 Créer le projet
1. Va sur **https://console.firebase.google.com**
2. **"Créer un projet"** → nom : `vide-frigo` → désactive Analytics → **Créer**

### 2.2 Activer l'authentification
1. Menu gauche → **Build → Authentication → Get started**
2. Onglet **"Sign-in method"** → **Email/Password** → activer → **Enregistrer**

### 2.3 Créer Firestore
1. Menu gauche → **Build → Firestore Database → Create database**
2. Choisir **"Start in test mode"** → région **eur3 (Europe)** → **Done**

### 2.4 Récupérer la config
1. Icône ⚙️ → **Project settings**
2. Section **"Your apps"** → icône **"</>"** (Web app)
3. Surnom : `vide-frigo-web` → **Register app**
4. Copie le bloc `firebaseConfig = { ... }` complet

---

## ÉTAPE 3 — Injecter les configs dans le HTML

Ouvre `vide-frigo.html` dans un éditeur (VS Code, Notepad…).

### 3.1 — Firebase config
Cherche :
```javascript
const FIREBASE_CONFIG = {
  apiKey: "REMPLACE_apiKey",
  ...
};
```
Remplace par ta vraie config Firebase.

### 3.2 — Clé Gemini
Cherche :
```javascript
const GEMINI_KEY = "REMPLACE_CLE_GEMINI_API";
```
Remplace par ta clé `AIzaSy...`

### 3.3 — Domaine autorisé Firebase
Après déploiement Netlify, reviens dans :
**Firebase → Authentication → Settings → Authorized domains**
Ajoute ton domaine `ton-app.netlify.app`

---

## ÉTAPE 4 — Déployer sur Netlify

1. Va sur **https://netlify.com** → crée un compte
2. Sur le tableau de bord : zone **"Drag and drop"**
3. Glisse `vide-frigo.html` dessus → URL générée en 30 secondes
4. Exemple : `https://vide-frigo-chef.netlify.app`

---

## ÉTAPE 5 — Activer Google AdSense (revenus pub)

### 5.1 Créer un compte AdSense
1. Va sur **https://adsense.google.com**
2. Crée un compte avec ton site Netlify
3. Attends validation Google (1 à 14 jours)

### 5.2 Intégrer la pub dans l'app
Une fois validé, dans le HTML cherche :
```html
<!-- <ins class="adsbygoogle" data-ad-client="ca-pub-XXXXX" ... -->
Espace publicitaire 468×50
```
Remplace par le code que Google AdSense te donne :
```html
<ins class="adsbygoogle"
  style="display:inline-block;width:468px;height:60px"
  data-ad-client="ca-pub-TON_ID"
  data-ad-slot="TON_SLOT">
</ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
```
Et ajoute dans le `<head>` :
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-TON_ID" crossorigin="anonymous"></script>
```

---

## ÉTAPE 6 — Sécuriser Firestore

Dans **Firestore → Rules** remplace les règles par :
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      match /history/{doc} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

---

## POUR LES STORES (prochaine étape)

Le web est prêt. Pour publier sur App Store et Google Play :

**Méthode recommandée : React Native**
1. Installe Node.js : https://nodejs.org
2. Installe React Native CLI :
   ```
   npx create-expo-app VideFrigo
   ```
3. On réutilise toute la logique métier (même Firebase, même Gemini)
4. On adapte l'UI avec les composants React Native
5. Publication sur les stores : compte Apple ($99/an) + Google ($25 une fois)

Dis-moi quand tu es prêt pour cette étape !

---

## Ce que l'app fait maintenant

### Fonctionnalités
- ✅ Comptes utilisateurs (email + mot de passe)
- ✅ Profils persistants (poids, objectifs, phase recompo)
- ✅ 3 modes : Classique / Sport / Recomposition
- ✅ Ingrédients favoris pré-sélectionnés
- ✅ Système D — substitutions intelligentes
- ✅ Recettes générées par Gemini (Google AI)
- ✅ Étapes cochables avec vibration
- ✅ Barre de progression en temps réel
- ✅ Confettis à la fin de chaque recette
- ✅ Système XP + niveaux (Apprenti → Étoile Michelin)
- ✅ 10 badges à débloquer
- ✅ Macros détaillées (sport/recomp)
- ✅ Conseil du Chef pour chaque recette
- ✅ Historique complet avec suppression
- ✅ Bandeau publicitaire prêt pour AdSense

### Stockage Firebase par utilisateur
```
users/{uid}/
  name, email, weight, xp, badges[]
  proto, fat, phase, activity, goals[]
  favIngredients[]
  history/
    nom, temps, mode, ingredients[]
    etapes[], macros, badge, savedAt, starred
```

---

## Problèmes fréquents

| Erreur | Cause | Solution |
|---|---|---|
| "Erreur Gemini API 400" | Clé invalide | Recrée une clé sur aistudio.google.com |
| "auth/operation-not-allowed" | Auth non activée | Firebase → Auth → Email/Password → activer |
| "Missing permissions" | Domaine non autorisé | Firebase → Auth → Authorized domains → ajouter ton URL |
| Confettis absents | CDN bloqué | Vérifie la connexion internet |
| Bandeau pub vide | AdSense pas validé | Normal au début, attends la validation Google |

