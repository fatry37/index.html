# 🚀 Guide d'installation complet — Vide-Frigo avec comptes utilisateurs

## Ce qu'on va faire
1. Créer un projet Firebase (gratuit) — gère les comptes + la base de données
2. Obtenir une clé API Anthropic — pour générer les recettes
3. Coller les deux configs dans le fichier HTML
4. Mettre en ligne sur Netlify en 2 minutes

---

## ÉTAPE 1 — Créer ton projet Firebase

### 1.1 — Créer le projet
1. Va sur **https://console.firebase.google.com**
2. Connecte-toi avec un compte Google
3. Clique **"Créer un projet"**
4. Donne un nom : `vide-frigo`
5. Désactive Google Analytics (pas nécessaire) → **Créer le projet**
6. Attends 30 secondes que ça se configure

### 1.2 — Activer l'authentification email/mot de passe
1. Dans le menu gauche → **"Build"** → **"Authentication"**
2. Clique **"Get started"**
3. Dans l'onglet **"Sign-in method"**, clique sur **"Email/Password"**
4. Active le premier toggle (Email/Password) → **Enregistrer**

### 1.3 — Créer la base de données Firestore
1. Menu gauche → **"Build"** → **"Firestore Database"**
2. Clique **"Create database"**
3. Choisis **"Start in test mode"** (tu durciras les règles plus tard)
4. Choisis la région **"eur3 (Europe)"** → **Done**

### 1.4 — Récupérer la configuration Firebase
1. Dans Firebase, clique l'icône ⚙️ (engrenage) → **"Project settings"**
2. Scroll vers le bas jusqu'à **"Your apps"**
3. Clique l'icône **"</>"** (Web app)
4. Donne un surnom : `vide-frigo-web` → **Register app**
5. Tu vas voir un bloc de code avec `firebaseConfig = { ... }`
6. **Copie tout ce bloc**, tu en auras besoin à l'étape 3

Le bloc ressemble à ça :
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXX",
  authDomain: "vide-frigo.firebaseapp.com",
  projectId: "vide-frigo",
  storageBucket: "vide-frigo.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456"
};
```

---

## ÉTAPE 2 — Obtenir ta clé API Anthropic

1. Va sur **https://console.anthropic.com**
2. Crée un compte (ou connecte-toi)
3. Menu gauche → **"API Keys"** → **"Create Key"**
4. Nom : `vide-frigo` → **Create Key**
5. **Copie la clé** (commence par `sk-ant-...`)
   ⚠️ Tu ne pourras plus la voir après — sauvegarde-la !

---

## ÉTAPE 3 — Injecter les configs dans le fichier HTML

Ouvre `vide-frigo.html` dans un éditeur de texte.

### 3.1 — Firebase config
Cherche ce bloc (vers la fin du fichier) :

```javascript
const firebaseConfig = {
  apiKey: "REMPLACE_PAR_TON_API_KEY",
  authDomain: "REMPLACE_PAR_TON_AUTH_DOMAIN",
  projectId: "REMPLACE_PAR_TON_PROJECT_ID",
  storageBucket: "REMPLACE_PAR_TON_STORAGE_BUCKET",
  messagingSenderId: "REMPLACE_PAR_TON_SENDER_ID",
  appId: "REMPLACE_PAR_TON_APP_ID"
};
```

Remplace-le par le bloc que tu as copié à l'étape 1.4.

### 3.2 — Clé Anthropic
Cherche cette ligne :

```javascript
const ANTHROPIC_KEY = "REMPLACE_PAR_TA_CLE_ANTHROPIC";
```

Remplace par ta clé :

```javascript
const ANTHROPIC_KEY = "sk-ant-TON_VRAI_TOKEN_ICI";
```

**Sauvegarde le fichier.**

---

## ÉTAPE 4 — Configurer le domaine autorisé dans Firebase

C'est une étape obligatoire sinon la connexion sera bloquée.

1. Firebase → **Authentication** → onglet **"Settings"**
2. Section **"Authorized domains"**
3. Tu verras `localhost` déjà là — c'est pour tester en local
4. Après le déploiement Netlify (étape 5), reviens ici et ajoute ton domaine Netlify
   Ex : `mon-app-12345.netlify.app`

---

## ÉTAPE 5 — Mettre en ligne sur Netlify

### Méthode ultra-rapide (2 minutes)
1. Va sur **https://netlify.com** → crée un compte gratuit
2. Sur le tableau de bord, tu vois : **"Drag and drop your site here"**
3. Glisse le fichier `vide-frigo.html` dessus
4. Netlify génère une URL : `https://quelquechose-123.netlify.app`
5. **Copie cette URL** et retourne dans Firebase ajouter le domaine (étape 4)

### Tester en local d'abord
Double-clique sur `vide-frigo.html` dans ton explorateur de fichiers.
Ça s'ouvre dans le navigateur. Crée un compte, connecte-toi et teste les recettes.
(Si CORS bloque l'API Anthropic en local, déploie sur Netlify directement)

---

## ÉTAPE 6 — Sécuriser Firestore (recommandé)

Par défaut tu es en "test mode" (tout le monde peut lire/écrire).
Pour sécuriser, va dans **Firestore → Rules** et remplace par :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      match /history/{docId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

Ça garantit que chaque utilisateur ne voit que ses propres données.

---

## Récapitulatif des coûts

| Service | Gratuit jusqu'à... |
|---|---|
| Firebase Authentication | 10 000 connexions/mois |
| Firestore | 1 Go stockage, 50 000 lectures/jour |
| Netlify hébergement | Illimité (sites statiques) |
| Anthropic API | ~0.003$/recette générée |

**Pour moins de 1 000 utilisateurs actifs** : tout reste gratuit sauf l'API Anthropic
(quelques euros par mois maximum selon l'usage).

---

## Ce que chaque utilisateur a dans son profil

Chaque compte stocke dans Firebase :
- Informations : prénom, poids
- Profil sportif : objectif protéines, matières grasses cibles, phase recompo, niveau d'activité
- Objectifs : liste de tags (sèche, prise de masse, endurance…)
- Ingrédients favoris : pré-sélectionnés automatiquement
- Historique complet : toutes les recettes générées, avec date, mode et possibilité de favori ★
  et de suppression ✕

---

## Problèmes fréquents

**"auth/operation-not-allowed"** → tu as oublié d'activer Email/Password dans Firebase Auth

**"FirebaseError: Missing or insufficient permissions"** → ajoute ton domaine dans
Firebase Auth → Settings → Authorized domains

**"401 Unauthorized" (Anthropic)** → ta clé API est invalide ou mal copiée

**Écran blanc / rien ne charge** → ouvre la console du navigateur (F12) pour voir l'erreur

---

## Structure des données dans Firestore

```
users/
  {userId}/
    name, email, weight, proto, fat, phase, activity, goals[], favIngredients[]
    history/
      {docId}/
        nom, temps, difficulte, mode, ingredients[], etapes[], macros, savedAt, starred
```

